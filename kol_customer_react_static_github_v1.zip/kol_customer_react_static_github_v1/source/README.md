# KØL Customer React

Dette er første React-versjon av kundesiden.

## Start lokalt

```bash
npm install
npm run dev
```

## Bygg

```bash
npm run build
```

Resultat havner i `dist/`.

## Firebase

Standard database er satt til:

```text
https://bestill-19-default-rtdb.europe-west1.firebasedatabase.app
```

Kan overstyres med `.env`:

```text
VITE_FIREBASE_DB=https://bestill-19-default-rtdb.europe-west1.firebasedatabase.app
VITE_PUBLIC_ORDER_BASE_URL=https://bestill.online/customer
```

## Struktur

- `src/App.jsx` hovedflyt
- `src/lib/api.js` Firebase REST kall
- `src/lib/dataAdapter.js` gjør gammel meny-data om til React-format
- `src/components/*` skjermkomponenter

Admin, SMS/Tampermonkey og kvittering er ikke flyttet i denne versjonen.
