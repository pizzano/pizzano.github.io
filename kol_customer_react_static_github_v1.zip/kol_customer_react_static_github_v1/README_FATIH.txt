KØL React müşteri uygulaması - hazır statik sürüm

KULLANMAK İÇİN EN KOLAY YOL:
1) ZIP'i aç.
2) customer klasörüne gir.
3) index.html dosyasına çift tıkla.

GITHUB'A EKLEME:
- Mevcut sipariş sistemini bozmadan denemek için customer klasörünü GitHub repoya koy.
- GitHub Pages açıksa şu şekilde çalışır:
  https://kullaniciadi.github.io/repo-adi/customer/

ANA SAYFA YAPMAK İSTERSEN:
- customer klasörünün içindeki index.html ve assets klasörünü repo kök dizinine taşı.
- Böylece React müşteri ekranı ana index olur.
- Admin panelini bozmak istemiyorsan admin.html eski haliyle kalabilir.

ÖNEMLİ:
- Bu klasör çalışmak için npm install istemez.
- source klasörü sadece ileride kod düzenlemek içindir.
- source ile çalışmak istersen o zaman npm gerekir, ama müşteri ekranını açmak için gerek yok.

Firebase:
- Varsayılan database: https://bestill-19-default-rtdb.europe-west1.firebasedatabase.app
- Değiştirmek gerekirse source/src/lib/api.js içinden DEFAULT_DB değişir ve tekrar build gerekir.
